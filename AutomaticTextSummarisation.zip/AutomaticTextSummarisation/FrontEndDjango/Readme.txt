1= install python
2= install django
3= setup django
4= create virtual env
5= install all necessary modules
	using pip install ---
*to download nltk 
*python
*>>>import nltk		//to check nltk is installed
*>>>nltk download
*pop up window will open download all package 
=======
to run project
1= workon (name of virtualenvironment)
2= change the directory of project file 
3= python manage.py runserver