from django import forms



class Formm(forms.Form):
	text = forms.CharField()

	

class URLForm(forms.Form):
	url = forms.URLField()

class DataForm(forms.Form):
	data = forms.CharField()




	