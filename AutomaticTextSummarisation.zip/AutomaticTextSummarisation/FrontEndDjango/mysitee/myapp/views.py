from django.shortcuts import render
from django.http import HttpResponse
from .forms import Formm, URLForm, DataForm


from .tfidf_summarization import tfidf_sum
from .nltk_summarization import nltk_summarizer
from .text_rank import TextRankSummarizer

from bs4 import BeautifulSoup
from urllib.request import urlopen 

#def Home(request):
    #return render(request,'myapp/Home.html')



def compare(request):
    text = 'No search query'
    percent = 40
    if request.method == 'POST':
        form = Formm(request.POST)
        if form.is_valid():
            text = form.cleaned_data.get('text')
            tfresult = tfidf_sum(text, percent)
            nltkresult = nltk_summarizer(text)
            tr = TextRankSummarizer(4)
            trresult = tr(text)
            return render(request, 'myapp/compare.html', {'tfresult':tfresult, 'nltkresult':nltkresult, 'trresult':trresult})
    
    return render(request,'myapp/compare.html')

def scrap(request):
    if request.method == 'POST':
        form = URLForm(request.POST)
        if form.is_valid():
            url = form.cleaned_data.get('url')
            page = urlopen(url)
            soup = BeautifulSoup(page)
            fetched_text = ' '.join(map(lambda p:p.text,soup.find_all('p')))
            return render(request, 'myapp/scrap.html', {'data':fetched_text})
    percent = 40
    if request.method == 'POST':
        form = DataForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data.get('data')
            urltfresult = tfidf_sum(data, percent)
            urlnltkresult = nltk_summarizer(data)
            tr = TextRankSummarizer(6)
            urltrresult = tr(data)
            return render(request, 'myapp/scrap.html', {'tfresult':urltfresult, 'nltkresult':urlnltkresult, 'trresult':urltrresult})
    return render(request,'myapp/scrap.html')